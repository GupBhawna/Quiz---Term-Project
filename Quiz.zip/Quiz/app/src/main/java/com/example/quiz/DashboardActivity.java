package com.example.quiz;

import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {
    String EmailHolder;
    TextView Email;
    Button Create ;
    Button Start;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        Email = (TextView)findViewById(R.id.textView1);
        Create = (Button)findViewById(R.id.buttonCreate);
        Start = (Button)findViewById(R.id.buttonStart);
        Intent intent = getIntent();
        // Receiving User Email Send By MainActivity.
        EmailHolder = intent.getStringExtra(MainActivity.UserEmail);
        // Setting up received email to TextView.
        Email.setText(Email.getText().toString()+ EmailHolder);
        // Adding click listener to Log Out button.
        Create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //The first parameter is the current Activity The second parameter is to start Activity
                Intent intent = new Intent(DashboardActivity.this,Quiz.class);
                startActivity(intent);
            }
        });

        Start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //The first parameter is the current Activity The second parameter is to start Activity
                Intent intent = new Intent(DashboardActivity.this,PlayQuiz.class);
                startActivity(intent);
            }
        });
    }
}